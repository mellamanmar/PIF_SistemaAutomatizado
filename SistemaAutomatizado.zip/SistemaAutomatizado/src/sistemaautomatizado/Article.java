
package sistemaautomatizado;


public class Article {
    
}
