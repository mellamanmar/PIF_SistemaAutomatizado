
package sistemaautomatizado;


public class Redactor {
    
}
